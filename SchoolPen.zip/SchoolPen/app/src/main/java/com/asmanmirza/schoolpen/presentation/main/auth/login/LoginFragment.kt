package com.asmanmirza.schoolpen.presentation.main.auth.login

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.asmanmirza.schoolpen.R
import com.asmanmirza.schoolpen.common.NetworkResponse
import com.asmanmirza.schoolpen.databinding.FragmentLoginBinding
import com.asmanmirza.schoolpen.domain.model.auth.AuthResponse
import com.google.gson.JsonObject
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LoginFragment : Fragment() {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    private val viewModel: LoginViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("UnsafeRepeatOnLifecycleDetector")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            ivBack.setOnClickListener { findNavController().popBackStack() }
            btnLogin.setOnClickListener {
                if (tietUserId.text?.isNotEmpty() == true && tietPassword.text?.isNotEmpty() == true)
                    JsonObject().apply {
                        addProperty("userName", tietUserId.text.toString())
                        addProperty("password", tietPassword.text.toString())
                    }.also { viewModel.login(it) }
                else
                    Toast.makeText(requireContext(), "Please enter both userId and Password", Toast.LENGTH_SHORT).show()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.response.collectLatest { response ->
                    when(response){
                        is NetworkResponse.Error -> {}
                        is NetworkResponse.Idle -> { }
                        is NetworkResponse.Loading -> { }
                        is NetworkResponse.Success -> {
                            val bundle = Bundle()
                            bundle.putString("user", binding.tietUserId.text.toString())
                            findNavController()
                                .navigate(R.id.action_loginFragment_to_hostFragment, args = bundle)
                            Toast.makeText(
                                requireContext(),
                                "Successfully logged in!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }
    }
}